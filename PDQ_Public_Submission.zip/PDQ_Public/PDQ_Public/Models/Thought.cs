﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PDQ_Public.Models
{
    public class Thought
    {
        public string Name { get; set; }
        public string CurrentBeer { get; set; }
        public string CurrentThought { get; set; }
        public string Daydream { get; set; }
        public string Photo { get; set; }
    }
}
