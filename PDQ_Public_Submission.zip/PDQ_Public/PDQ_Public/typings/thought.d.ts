﻿export interface IThought {
    name: string;
    currentBeer: string;
    currentThought: string;
    daydream: string;
    photo: string;
}