"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const React = __importStar(require("react"));
class Thought extends React.Component {
    componentDidMount() {
        this.setState({ ready: true });
    }
    render() {
        if (!this.state || !this.props)
            return React.createElement("div", null);
        let thought = this.props.thought;
        let { photo, currentBeer, name, currentThought, daydream } = thought;
        if (thought && !name)
            return (React.createElement("div", { style: { textAlign: 'center', opacity: .7, marginTop: '50px' } },
                React.createElement("div", { style: { fontSize: '200px' } },
                    React.createElement("i", { className: "fa fa-exclamation-triangle fa-exlamation-triangle" })),
                React.createElement("h2", { style: { fontSize: '100px' } }, "Brain Unavailable"),
                React.createElement("p", null,
                    React.createElement("i", null, "Please Try Again"))));
        return (React.createElement("div", { className: "thought-container" },
            React.createElement("div", { className: "flex-grow-0", style: { flex: "65%" } },
                React.createElement("img", { className: "img-thumbnail", src: photo }),
                React.createElement("div", null,
                    React.createElement("h3", { style: { padding: '10px 0' } }, name),
                    React.createElement("h6", null, "Preferred Brew:"),
                    React.createElement("p", { style: { padding: "5px" } }, currentBeer))),
            React.createElement("div", { style: { marginLeft: '50px' } },
                React.createElement("h6", null, "Thought:"),
                React.createElement("div", { style: { padding: "20px" } },
                    "\"",
                    currentThought,
                    "\""),
                React.createElement("h6", null, "Daydream:"),
                React.createElement("img", { className: "daydream", src: daydream }))));
    }
}
exports.Thought = Thought;
