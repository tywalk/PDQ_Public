# PDQ_Public

This project contains an interface for the Cabalistic Necromancer.

To get it up and running...

**Run:** (at \PDQ_Public\PDQ_Public)

```
npm install
npm run release
docker-compose up
```

Then, navigate from a browser: https://localhost:44326.

*This project was creating running in a windows environment.*