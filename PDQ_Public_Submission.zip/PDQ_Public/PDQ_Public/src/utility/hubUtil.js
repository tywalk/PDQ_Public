"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const SignalR = __importStar(require("@aspnet/signalr"));
var BaseHubUtility;
(function (BaseHubUtility) {
    class Hub {
        constructor(onStart, onReceive, receiveMessage, otherMessages) {
            this.onStart = onStart;
            this.onReceive = onReceive;
            this.receiveMessage = receiveMessage;
            this.otherMessages = otherMessages;
            /** Triggers onStart callback.
             * @param chat Successful connection. */
            this.forStart = (chat) => {
                this.onStart && this.onStart(chat);
            };
            try {
                //Set signalr connection
                this.connection = new SignalR.HubConnectionBuilder()
                    .withUrl("/hub")
                    .build();
                //Initialize event handlers
                this.init(onReceive, receiveMessage, otherMessages);
            }
            catch (e) {
                //No connection found
                this.connection = new SignalR.HubConnectionBuilder().build();
                alert("No connection.");
            }
        }
        /**
         * Initialize connection and handlers.
         * @param onReceive
         * @param receiveMessage
         * @param otherMessages
         */
        init(onReceive, receiveMessage, otherMessages) {
            return __awaiter(this, void 0, void 0, function* () {
                yield this.connection.start().catch(err => document.write(err));
                this.forStart(this.connection); //Connection made
                this.connection.on(receiveMessage, onReceive); //Add default message and handler
                //Add additional messages to the hub
                if (otherMessages)
                    for (var msg in otherMessages) {
                        this.connection.on(msg, otherMessages[msg]);
                    }
            });
        }
        /**
         * Sends data to hub using default connection params.
         * @param data
         * @param connection
         */
        sendToServer(data, connection) {
            if (this.connection && this.connection.server && connection)
                this.connection.server.send(data);
            else
                this.connection.send(data);
        }
        /** Invoke 'LockApi' message. */
        lockApi() {
            return __awaiter(this, void 0, void 0, function* () {
                if (this.connection) {
                    let canUpdate = yield this.connection.invoke("LockApi");
                    return canUpdate;
                }
                return false;
            });
        }
        /** Invoke 'UnlockApi' message. */
        unlockApi() {
            return __awaiter(this, void 0, void 0, function* () {
                if (this.connection) {
                    let canUpdate = yield this.connection.invoke("UnlockApi");
                    return canUpdate;
                }
                return false;
            });
        }
        /** Invoke 'GetThought' message.
         * Retrieve current thought from brain. */
        getThought() {
            return __awaiter(this, void 0, void 0, function* () {
                if (this.connection) {
                    let thought = yield this.connection.invoke("GetThought");
                    return thought;
                }
                return false;
            });
        }
    }
    BaseHubUtility.Hub = Hub;
})(BaseHubUtility = exports.BaseHubUtility || (exports.BaseHubUtility = {}));
/** Utility to communicate with the hub. */
class HubUtility extends BaseHubUtility.Hub {
}
exports.HubUtility = HubUtility;
